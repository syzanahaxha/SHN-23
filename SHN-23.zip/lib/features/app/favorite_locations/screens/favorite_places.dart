import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class PlacesScreen extends StatefulWidget {
  @override
  _PlacesScreenState createState() => _PlacesScreenState();
}

class _PlacesScreenState extends State<PlacesScreen> {
  List<String> places = [];

  @override
  void initState() {
    super.initState();
    _loadPlaces();
  }

  Future<void> _loadPlaces() async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    List<String>? markersList = prefs.getStringList('markers');
    if (markersList != null) {
      setState(() {
        places = markersList;
      });
    }
  }

  Future<void> _editTitle(int index, String newTitle) async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    List<String> markersList = prefs.getStringList('markers') ?? [];
    if (markersList.isNotEmpty && index < markersList.length) {
      List<String> placeInfo = markersList[index].split(',');
      if (placeInfo.length >= 4) {
        placeInfo[2] = newTitle;
        markersList[index] = placeInfo.join(',');
        await prefs.setStringList('markers', markersList);
        await _loadPlaces();
      }
    }
  }

  Future<void> _deletePlace(int index) async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    List<String> markersList = prefs.getStringList('markers') ?? [];
    if (markersList.isNotEmpty && index < markersList.length) {
      markersList.removeAt(index);
      await prefs.setStringList('markers', markersList);
      await _loadPlaces();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Color(0xff0a4766),
        title: Center(
          child: Text(
            "Favorite Places",
            style: TextStyle(
              color: Colors.white,
              fontSize: 25,
            ),
          ),
        ),
        actions: <Widget>[
          PopupMenuButton<String>(
            icon: Icon(Icons.person),
            onSelected: (value) {
              if (value == 'profile') {
                // Handle profile click
              } else if (value == 'favorite') {
                Navigator.pushReplacementNamed(context, "/home");
              } else if (value == 'signout') {
                FirebaseAuth.instance.signOut();
                Navigator.pushReplacementNamed(context, "/login");
              }
            },
            itemBuilder: (BuildContext context) {
              return [
                PopupMenuItem<String>(
                  value: 'profile',
                  child: Row(
                    children: [
                      Icon(Icons.person),
                      SizedBox(width: 10),
                      Text('Profile'),
                    ],
                  ),
                ),
                PopupMenuItem<String>(
                  value: 'favorite',
                  child: Row(
                    children: [
                      Icon(Icons.favorite),
                      SizedBox(width: 10),
                      Text('Add a Place'),
                    ],
                  ),
                ),
                PopupMenuItem<String>(
                  value: 'signout',
                  child: Row(
                    children: [
                      Icon(Icons.logout),
                      SizedBox(width: 10),
                      Text('Sign Out'),
                    ],
                  ),
                ),
              ];
            },
          ),
        ],
      ),
      body: ListView.separated(
        itemCount: places.length,
        separatorBuilder: (BuildContext context, int index) => Divider(),
        itemBuilder: (context, index) {
          List<String> placeInfo = places[index].split(',');
          if (placeInfo.length >= 2) {
            double latitude = double.parse(placeInfo[0]);
            double longitude = double.parse(placeInfo[1]);
            return Padding(
              padding: const EdgeInsets.symmetric(vertical: 8.0),
              child: Container(
                decoration: BoxDecoration(
                  color: Colors.blue[50],
                  borderRadius: BorderRadius.circular(10),
                ),
                child: ListTile(
                  title: Row(
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              placeInfo.length > 2 ? placeInfo[2] : 'No Title',
                              style: TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 18,
                                color: Colors.black54,
                              ),
                            ),
                            Text(
                              placeInfo.length > 3
                                  ? placeInfo[3]
                                  : 'No Description',
                              style: TextStyle(
                                  fontSize: 16, color: Colors.black54),
                            ),
                          ],
                        ),
                      ),
                      IconButton(
                        icon: Icon(Icons.edit),
                        color: Colors.black54,
                        onPressed: () {
                          showDialog(
                            context: context,
                            builder: (BuildContext context) {
                              String newTitle = placeInfo[2];
                              return AlertDialog(
                                title: Text('Edit Title'),
                                content: TextField(
                                  onChanged: (value) {
                                    newTitle = value;
                                  },
                                  controller:
                                      TextEditingController(text: newTitle),
                                ),
                                actions: [
                                  TextButton(
                                    onPressed: () {
                                      _editTitle(index, newTitle);
                                      Navigator.of(context).pop();
                                    },
                                    child: Text('Save'),
                                  ),
                                ],
                              );
                            },
                          );
                        },
                      ),
                      IconButton(
                        icon: Icon(Icons.delete),
                        color: Colors.black54,
                        onPressed: () {
                          _deletePlace(index);
                        },
                      ),
                    ],
                  ),
                  subtitle: Text(
                    'Latitude: $latitude, Longitude: $longitude',
                    style: TextStyle(fontSize: 16),
                  ),
                ),
              ),
            );
          } else {
            return Padding(
              padding:
                  const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
              child: Container(
                decoration: BoxDecoration(
                  color: Colors.blue[50],
                  borderRadius: BorderRadius.circular(10),
                ),
                child: ListTile(
                  title: Text(
                    'Invalid Place',
                    style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
                  ),
                ),
              ),
            );
          }
        },
      ),
    );
  }
}
