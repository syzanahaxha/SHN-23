import 'dart:async';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'favorite_places.dart';
import 'package:firebase_auth/firebase_auth.dart';

class MapSample extends StatefulWidget {
  const MapSample({Key? key}) : super(key: key);

  @override
  State<MapSample> createState() => MapSampleState();
}

class MapSampleState extends State<MapSample> {
  final Completer<GoogleMapController> _controller =
      Completer<GoogleMapController>();

  static const CameraPosition _kGooglePlex = CameraPosition(
    target: LatLng(42.6026, 20.9030), // Kosovo coordinates
    zoom: 7.6,
  );

  Set<Marker> _markers = {};
  bool _isAddingPlace = false;

  String title = '';
  String description = '';
  Future<void> _addMarker(LatLng location) async {
    if (_isAddingPlace) {
      final GoogleMapController controller = await _controller.future;
      bool isButtonDisabled = false; // Add this variable

      showDialog(
        context: context,
        builder: (BuildContext context) {
          return StatefulBuilder(
            builder: (BuildContext context, setState) {
              return AlertDialog(
                title: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text('Add a Place'),
                    GestureDetector(
                      onTap: isButtonDisabled // Check if button is disabled
                          ? null
                          : () {
                              setState(() {
                                isButtonDisabled = true; // Disable button
                              });
                              Navigator.of(context).pop();
                            },
                      child: Icon(Icons.close),
                    ),
                  ],
                ),
                content: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: <Widget>[
                    TextField(
                      decoration: InputDecoration(labelText: 'Title'),
                      onChanged: (value) {
                        setState(() {
                          title = value;
                        });
                      },
                    ),
                    TextField(
                      decoration: InputDecoration(labelText: 'Description'),
                      onChanged: (value) {
                        setState(() {
                          description = value;
                        });
                      },
                    ),
                  ],
                ),
                actions: <Widget>[
                  TextButton(
                    onPressed: () {
                      _saveMarkers(location);
                      Navigator.of(context).pop();
                      setState(() {
                        _isAddingPlace = false; // Resetting the flag here
                      });
                    },
                    child: Text('Save'),
                  ),
                ],
              );
            },
          );
        },
      );
    }
  }

  Future<void> _saveMarkers(LatLng location) async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    List<String> markersList = prefs.getStringList('markers') ?? [];
    markersList.add(
        '${location.latitude},${location.longitude},${title ?? 'No Title'},${description ?? 'No Description'}');
    await prefs.setStringList('markers', markersList);
    _loadMarkers();
  }

  Future<void> _goToTheLake() async {
    // Add functionality to go to the lake here
  }

  Future<void> _loadMarkers() async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    List<String>? markersList = prefs.getStringList('markers');
    if (markersList != null) {
      setState(() {
        _markers = markersList.map((marker) {
          List<String> markerInfo = marker.split(',');
          return Marker(
            markerId: MarkerId(marker),
            position: LatLng(
                double.parse(markerInfo[0]), double.parse(markerInfo[1])),
            infoWindow: InfoWindow(
              title: markerInfo.length > 2 ? markerInfo[2] : 'No Title',
              snippet: markerInfo.length > 3 ? markerInfo[3] : 'No Description',
            ),
            icon: BitmapDescriptor.defaultMarker,
          );
        }).toSet();
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Color(0xff0a4766),
        title: Center(
          child: Text(
            "Favorite Places",
            style: TextStyle(
              color: Colors.white,
              fontSize: 25,
            ),
          ),
        ),
        actions: <Widget>[
          PopupMenuButton<String>(
            icon: Icon(Icons.person),
            onSelected: (value) {
              if (value == 'profile') {
                // Handle profile click
              } else if (value == 'favorite') {
                Navigator.pushReplacementNamed(context, "/places");
              } else if (value == 'signout') {
                FirebaseAuth.instance.signOut();
                Navigator.pushReplacementNamed(context, "/login");
              }
            },
            itemBuilder: (BuildContext context) {
              return [
                PopupMenuItem<String>(
                  value: 'profile',
                  child: Row(
                    children: [
                      Icon(Icons.person),
                      SizedBox(width: 10),
                      Text('Profile'),
                    ],
                  ),
                ),
                PopupMenuItem<String>(
                  value: 'favorite',
                  child: Row(
                    children: [
                      Icon(Icons.favorite),
                      SizedBox(width: 10),
                      Text('Favorite Places'),
                    ],
                  ),
                ),
                PopupMenuItem<String>(
                  value: 'signout',
                  child: Row(
                    children: [
                      Icon(Icons.logout),
                      SizedBox(width: 10),
                      Text('Sign Out'),
                    ],
                  ),
                ),
              ];
            },
          ),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: GoogleMap(
              mapType: MapType.hybrid,
              initialCameraPosition: _kGooglePlex,
              onMapCreated: (GoogleMapController controller) {
                _controller.complete(controller);
                _loadMarkers();
              },
              markers: _markers,
              onTap: _isAddingPlace
                  ? (LatLng location) {
                      _addMarker(location);
                    }
                  : null,
            ),
          ),
        ],
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.startFloat,
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          setState(() {
            _isAddingPlace = !_isAddingPlace;
          });
        },
        backgroundColor: _isAddingPlace ? Colors.blue[800] : Color(0xff0a4766),
        foregroundColor: Colors.white,
        child: Icon(Icons.add),
      ),
    );
  }
}
