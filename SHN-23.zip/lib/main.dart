import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:noexis_flutter_task/features/app/favorite_locations/screens/favorite_places.dart';
import 'package:noexis_flutter_task/features/app/favorite_locations/screens/map_screen.dart';
import 'package:noexis_flutter_task/features/app/splash-screen/splash_screen.dart';
import 'package:noexis_flutter_task/features/user_auth/presentation/pages/login_page.dart';

import 'features/user_auth/presentation/pages/home_page.dart';
import 'features/user_auth/presentation/pages/sign_up_page.dart';

Future main() async {
  WidgetsFlutterBinding.ensureInitialized();
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: FirebaseOptions(
            apiKey: "AIzaSyDxYSLz6ap4kh5_KNJQv9ubSvTUBb7baBw",
            appId: "1:788580219301:web:2202bfd3e6eba86fb9104c",
            messagingSenderId: "788580219301",
            projectId: "noexis-flutter-task"));
  }
  await Firebase.initializeApp();
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        debugShowCheckedModeBanner: false,
        // Application name
        title: 'Flutter Hello World',
        // Application theme data, you can set the colors for the application as
        // you want
        theme: ThemeData(
          primarySwatch: Colors.blue,
        ),
        routes: {
          '/': (context) => SplashScreen(
              // Here, you can decide whether to show the LoginPage or HomePage based on user authentication
              child: LoginPage()),
          // child: MapSample()),
          '/login': (context) => LoginPage(),
          '/signUp': (context) => SignUpPage(),
          '/home': (context) => MapSample(),
          '/places': (context) => PlacesScreen(),
        }
        // A widget which will be started on application startup
        // home: SplashScreen(child: LoginPage()));
        );
  }
}

class MyHomePage extends StatelessWidget {
  final String title;
  const MyHomePage({super.key, required this.title});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        // The title text which will be shown on the action bar
        title: Text(title),
      ),
      body: Center(
        child: Text(
          'Hello, World!',
        ),
      ),
    );
  }
}
